<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/delete_helpers.php';
require_roles([ROLE_SUPER_ADMIN]);

$errors = [];
$success = [];

$school = $pdo->query('SELECT id, name, logo_path FROM schools ORDER BY id ASC LIMIT 1')->fetch();
if (!$school) {
    $pdo->exec("INSERT INTO schools (name) VALUES ('My School')");
    $school = $pdo->query('SELECT id, name, logo_path FROM schools ORDER BY id ASC LIMIT 1')->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_school') {
        $name = trim($_POST['school_name'] ?? '');
        $logoPath = trim($_POST['logo_path'] ?? '');

        if ($name === '') {
            $errors[] = 'School name is required.';
        } else {
            $logoUpdateClause = '';
            $params = [
                'name' => $name,
                'id' => $school['id'],
            ];

            if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../../assets/uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $filename = time() . '_' . basename($_FILES['school_logo']['name']);
                $targetPath = $uploadDir . $filename;
                if (move_uploaded_file($_FILES['school_logo']['tmp_name'], $targetPath)) {
                    $logoUpdateClause = ', logo_path = :logo_path';
                    $params['logo_path'] = '/itierp/assets/uploads/' . $filename;
                }
            }

            $stmt = $pdo->prepare('UPDATE schools SET name = :name' . $logoUpdateClause . ' WHERE id = :id');
            $stmt->execute($params);
            $success[] = 'School settings updated.';
        }
    }

    if ($action === 'create_session') {
        $title = trim($_POST['title'] ?? '');
        $startDate = $_POST['start_date'] ?? '';
        $endDate = $_POST['end_date'] ?? '';
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if ($title === '' || $startDate === '' || $endDate === '') {
            $errors[] = 'Session title and date range are required.';
        } elseif ($startDate > $endDate) {
            $errors[] = 'Session start date cannot be after end date.';
        } else {
            try {
                $pdo->beginTransaction();

                // Allow multiple active sessions natively
                // Removed global deactivation

                $stmt = $pdo->prepare(
                    'INSERT INTO academic_sessions (school_id, title, start_date, end_date, is_active)
                     VALUES (:school_id, :title, :start_date, :end_date, :is_active)'
                );
                $stmt->execute([
                    'school_id' => $school['id'],
                    'title' => $title,
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                    'is_active' => $isActive,
                ]);

                $pdo->commit();
                $success[] = 'Academic session created.';
            } catch (Throwable $throwable) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = 'Unable to create session: ' . $throwable->getMessage();
            }
        }
    }

    if ($action === 'activate_session') {
        $sessionId = (int)($_POST['session_id'] ?? 0);
        if ($sessionId <= 0) {
            $errors[] = 'Invalid session selected.';
        } else {
            try {
                $pdo->beginTransaction();
                $pdo->exec('UPDATE academic_sessions SET is_active = 0');
                $stmt = $pdo->prepare('UPDATE academic_sessions SET is_active = 1 WHERE id = :id');
                $stmt->execute(['id' => $sessionId]);
                $pdo->commit();
                $success[] = 'Academic session activated.';
            } catch (Throwable $throwable) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = 'Unable to activate session: ' . $throwable->getMessage();
            }
        }
    }

    if ($action === 'delete_session') {
        $sessionId = (int)($_POST['session_id'] ?? 0);
        if ($sessionId <= 0) {
            $errors[] = 'Invalid session delete request.';
        } else {
            try {
                $pdo->beginTransaction();

                $classIdsStmt = $pdo->prepare('SELECT id FROM classes WHERE session_id = :session_id');
                $classIdsStmt->execute(['session_id' => $sessionId]);
                $classIds = array_map(static fn(array $row): int => (int)$row['id'], $classIdsStmt->fetchAll());

                foreach ($classIds as $classId) {
                    cascade_delete_class($pdo, $classId);
                }

                $deleteSession = $pdo->prepare('DELETE FROM academic_sessions WHERE id = :id');
                $deleteSession->execute(['id' => $sessionId]);

                if ($deleteSession->rowCount() < 1) {
                    throw new RuntimeException('Session not found or could not be deleted.');
                }

                $pdo->commit();
                $success[] = 'Academic session deleted with related courses and records.';
            } catch (Throwable $throwable) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = 'Unable to delete session: ' . $throwable->getMessage();
            }
        }
    }

    if ($action === 'apply_maintenance_unlock_key') {
        $key = trim($_POST['unlock_key'] ?? '');
        $res = verify_and_apply_unlock($pdo, $key, 'renew_1year');
        if ($res['success']) {
            $success[] = $res['message'];
        } else {
            $errors[] = $res['message'];
        }
    }

    $school = $pdo->query('SELECT id, name, logo_path FROM schools ORDER BY id ASC LIMIT 1')->fetch();
}

$sessions = $pdo->query(
    'SELECT a.id, a.title, a.start_date, a.end_date, a.is_active,
            COUNT(c.id) AS class_count
     FROM academic_sessions a
     LEFT JOIN classes c ON c.session_id = a.id
     GROUP BY a.id, a.title, a.start_date, a.end_date, a.is_active
     ORDER BY a.is_active DESC, a.start_date DESC'
)->fetchAll();

$pageTitle = 'System Academic Settings';
require __DIR__ . '/../../includes/header.php';
?>
<section class="card">
    <h2>School System Settings</h2>

    <?php if (!empty($errors)): ?>
        <div class="error">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="success">
            <?php foreach ($success as $message): ?>
                <p><?= htmlspecialchars($message) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- CLEAN TABLES VIEW FIRST -->
    <section class="card">
        <div class="form-header-actions">
            <h3>Academic Sessions</h3>
            <div class="toolbar-actions-tight">
                <button type="button" class="btn-toggle-form" onclick="toggleForm('form-session', this)">+ Add Session</button>
                <button type="button" class="btn-toggle-form" onclick="toggleForm('form-school', this)">Edit School Profile</button>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Duration</th>
                        <th>Courses</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sessions as $session): ?>
                        <tr>
                            <td><?= htmlspecialchars((string)$session['title']) ?></td>
                            <td><?= htmlspecialchars((string)$session['start_date']) ?> → <?= htmlspecialchars((string)$session['end_date']) ?></td>
                            <td><?= (int)$session['class_count'] ?></td>
                            <td><span class="pill"><?= (int)$session['is_active'] === 1 ? 'Active' : 'Inactive' ?></span></td>
                            <td>
                                    <form method="post" class="inline-form">
                                        <input type="hidden" name="action" value="toggle_session_active">
                                        <input type="hidden" name="session_id" value="<?= (int)$session['id'] ?>">
                                        <input type="hidden" name="is_active" value="<?= (int)$session['is_active'] === 1 ? '0' : '1' ?>">
                                        <?php if ((int)$session['is_active'] === 1): ?>
                                            <button type="submit" class="danger">Deactivate</button>
                                        <?php else: ?>
                                            <button type="submit">Activate</button>
                                        <?php endif; ?>
                                    </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($sessions)): ?>
                        <tr><td colspan="5">No academic sessions found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- ANNUAL MAINTENANCE & LICENSE CONTRACT SECTION -->
    <?php $superadminMaint = get_maintenance_status($pdo, true); ?>
    <section class="card" id="amc-license-section" style="margin-top: 24px; border: 1px solid var(--outline-variant);">
        <div class="form-header-actions" style="margin-bottom: 16px;">
            <div>
                <h3>Annual ERP Maintenance & License Contract</h3>
                <p>Monitor your software renewal status, view vendor support contacts, and enter renewal keys.</p>
            </div>
            <div>
                <?php if ($superadminMaint['status_code'] === 'grace_period'): ?>
                    <span class="pill" style="background: var(--error); color: #fff; font-weight: 700;">
                        🚨 GRACE PERIOD (<?= $superadminMaint['grace_days_left'] ?> DAYS LEFT)
                    </span>
                <?php elseif ($superadminMaint['is_warning']): ?>
                    <span class="pill" style="background: #d97706; color: #fff; font-weight: 700;">
                        ⚠️ RENEWAL DUE SOON (<?= $superadminMaint['days_remaining'] ?> DAYS LEFT)
                    </span>
                <?php else: ?>
                    <span class="pill" style="background: #15803d; color: #fff; font-weight: 700;">
                        ✅ ACTIVE (DUE IN <?= $superadminMaint['days_remaining'] ?> DAYS)
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid-3" style="margin-bottom: 20px;">
            <div style="background: var(--surface-container-highest); padding: 14px; border-radius: 8px;">
                <p style="font-size: 0.78rem; text-transform: uppercase; color: var(--on-surface-variant); font-weight: 700;">Due Date</p>
                <p style="font-size: 1.15rem; font-weight: 700; color: var(--on-surface); margin-top: 4px;"><?= htmlspecialchars($superadminMaint['due_date_formatted']) ?></p>
            </div>
            <div style="background: var(--surface-container-highest); padding: 14px; border-radius: 8px;">
                <p style="font-size: 0.78rem; text-transform: uppercase; color: var(--on-surface-variant); font-weight: 700;">Annual AMC Fee</p>
                <p style="font-size: 1.15rem; font-weight: 700; color: var(--on-surface); margin-top: 4px;">
                    <?= ($superadminMaint['currency'] === 'INR' ? '₹' : $superadminMaint['currency']) . ' ' . number_format($superadminMaint['annual_fee'], 2) ?>
                </p>
            </div>
            <div style="background: var(--surface-container-highest); padding: 14px; border-radius: 8px;">
                <p style="font-size: 0.78rem; text-transform: uppercase; color: var(--on-surface-variant); font-weight: 700;">Grace Period Deadline</p>
                <p style="font-size: 1.15rem; font-weight: 700; color: var(--on-surface); margin-top: 4px;"><?= htmlspecialchars($superadminMaint['grace_deadline_formatted']) ?></p>
            </div>
        </div>

        <div class="grid-2" style="margin-bottom: 20px;">
            <div style="background: var(--surface-container-lowest); border: 1px solid var(--outline-variant); padding: 16px; border-radius: 8px;">
                <h4 style="margin-bottom: 8px; font-size: 0.95rem;">Technical Support & Renewal Inquiries</h4>
                <p style="margin-bottom: 4px;"><strong>Provider:</strong> <?= htmlspecialchars($superadminMaint['contact_person']) ?></p>
                <?php if ($superadminMaint['contact_phone']): ?>
                    <p style="margin-bottom: 4px;"><strong>Phone / WhatsApp:</strong> <a href="tel:<?= htmlspecialchars($superadminMaint['contact_phone']) ?>"><?= htmlspecialchars($superadminMaint['contact_phone']) ?></a></p>
                <?php endif; ?>
                <?php if ($superadminMaint['contact_email']): ?>
                    <p><strong>Email:</strong> <a href="mailto:<?= htmlspecialchars($superadminMaint['contact_email']) ?>"><?= htmlspecialchars($superadminMaint['contact_email']) ?></a></p>
                <?php endif; ?>
            </div>

            <div style="background: var(--surface-container-lowest); border: 1px solid var(--outline-variant); padding: 16px; border-radius: 8px;">
                <h4 style="margin-bottom: 8px; font-size: 0.95rem;">Enter License Renewal / Unlock Key</h4>
                <p style="font-size: 0.85rem; margin-bottom: 12px; color: var(--on-surface-variant);">
                    Once you receive your renewal key from the vendor, enter it here to instantly extend your license for 1 year.
                </p>
                <form method="post" style="display: flex; gap: 8px;">
                    <input type="hidden" name="action" value="apply_maintenance_unlock_key">
                    <input type="text" name="unlock_key" required placeholder="Enter key (e.g. AMC-2026-...)" style="flex: 1; padding: 8px 12px; font-family: monospace;">
                    <button type="submit" style="padding: 8px 16px; font-weight: 700;">Validate & Apply</button>
                </form>
            </div>
        </div>

        <!-- UPI Payment QR Code Section -->
        <div style="background: var(--surface-container-highest); padding: 22px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
            <p style="font-size: 0.82rem; text-transform: uppercase; font-weight: 700; color: var(--on-surface-variant); margin-bottom: 4px; letter-spacing: 0.05em;">Scan & Pay via UPI</p>
            <p style="font-size: 0.88rem; color: var(--on-surface); margin-bottom: 14px;">Scan with Google Pay, PhonePe, Paytm, BHIM, or any UPI banking app to renew your ERP license.</p>
            <?php if (!empty($superadminMaint['upi_qr_path'])): ?>
                <div style="display: inline-block; background: #ffffff; border: 1px solid var(--outline-variant); padding: 12px; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <img src="<?= htmlspecialchars($superadminMaint['upi_qr_path']) ?>" alt="UPI QR Code" style="width: 170px; height: 170px; object-fit: contain; display: block; border-radius: 6px;">
                </div>
            <?php else: ?>
                <div style="background: var(--surface); border: 2px dashed var(--outline-variant); border-radius: 10px; padding: 20px; max-width: 320px; margin: 0 auto;">
                    <p style="font-size: 1.8rem; margin-bottom: 6px;">📷</p>
                    <p style="font-weight: 700;">UPI Payment QR Code</p>
                    <p style="font-size: 0.82rem; color: var(--on-surface-variant); margin-top: 4px;">Contact developer on WhatsApp to receive the QR code.</p>
                </div>
            <?php endif; ?>
            <div style="margin-top: 12px;">
                <span style="font-size: 0.85rem; color: var(--on-surface-variant);">Annual Maintenance Fee:</span>
                <strong style="color: var(--primary); font-size: 1.05rem; margin-left: 6px;">
                    <?= ($superadminMaint['currency'] === 'INR' ? '₹' : $superadminMaint['currency']) . ' ' . number_format($superadminMaint['annual_fee'], 2) ?>
                </strong>
            </div>
        </div>

            <!-- WhatsApp Screenshot Verification Prompt -->
            <div style="background: linear-gradient(135deg, rgba(34, 197, 94, 0.12) 0%, rgba(16, 185, 129, 0.06) 100%); border: 1px solid rgba(34, 197, 94, 0.35); border-radius: 10px; padding: 16px 18px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 14px; flex: 1; min-width: 240px;">
                    <span style="font-size: 1.8rem;">📲</span>
                    <div>
                        <h5 style="color: #15803d; font-size: 0.95rem; font-weight: 700; margin-bottom: 2px;">After Payment: Send Screenshot on WhatsApp</h5>
                        <p style="font-size: 0.88rem; color: var(--on-surface); line-height: 1.4;">
                            After making the payment, please send the payment screenshot on WhatsApp to <strong>+91 84299 39031</strong> for immediate activation and license renewal.
                        </p>
                    </div>
                </div>
                <a href="https://wa.me/918429939031?text=Hello%2C%20I%20have%20paid%20the%20ERP%20Yearly%20Maintenance.%20Please%20find%20attached%20payment%20screenshot%20for%20verification." target="_blank" class="btn-compact" style="background: #22c55e; color: #0b111e; font-weight: 700; padding: 8px 16px; text-decoration: none; border-radius: 6px; display: inline-flex; align-items: center; gap: 6px;">
                    <span>💬</span> Send Screenshot to +91 84299 39031
                </a>
            </div>
    </section>

</section>

<div id="form-school" class="collapsible-form">
    <section class="card">
        <h3>School Profile</h3>
        <form method="post" class="form-grid form-grid-wide" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update_school">

            <label>School Name</label>
            <input type="text" name="school_name" value="<?= htmlspecialchars((string)$school['name']) ?>" required>

            <label>Upload Logo</label>
            <input type="file" name="school_logo" accept="image/*">
            <?php if (!empty($school['logo_path'])): ?>
                <div style="margin-top: 10px;">
                    <p><small>Current Logo:</small></p>
                    <img src="<?= htmlspecialchars((string)$school['logo_path']) ?>" alt="School Logo" style="max-height: 50px;">
                </div>
            <?php endif; ?>

            <button type="submit">Save School Settings</button>
        </form>
    </section>
</div>

<div id="form-session" class="collapsible-form">
    <section class="card">
        <h3>Create Academic Session</h3>
        <form method="post" class="form-grid form-grid-wide">
            <input type="hidden" name="action" value="create_session">

            <label>Session Title</label>
            <input type="text" name="title" placeholder="2026-2027" required>

            <label>Start Date</label>
            <input type="date" name="start_date" required>

            <label>End Date</label>
            <input type="date" name="end_date" required>

            <label>
                <input type="checkbox" name="is_active" checked>
                Mark as active session
            </label>

            <button type="submit">Add Session</button>
        </form>
    </section>
</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
